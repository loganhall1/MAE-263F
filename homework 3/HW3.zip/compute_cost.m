%Name: Logan Hall
%UID: 206295698
%File Name: compute_cost.m
%File Description:
%The given function calculates the cross-entropy loss,
%also known as the log loss, given the predicted values
%AL and the true values Y
%Inputs:
%AL: final predicted values, a K x N matrix. K is the number of all classes, and N is the number of examples. 
%Y: ground truth labels, a K x N matrix. K is the number of all classes, and N is the number of examples.
%Output:
%cost: the entropy loss

function cost = compute_cost(AL, Y)
    cost = -sum(Y .* log(AL)); %Calculate cost as cross-entropy loss
end