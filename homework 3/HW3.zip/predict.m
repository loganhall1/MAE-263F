function Y_pred = predict(X, parameters)
%Name: Logan Hall
%UID: 206295698
%File Name: predict.m
%File Description:
% Returns the predicted classes of the inference images using parameters containing the weights and biases of the neural network.
% Inputs:
%         X: Inference images with sizes 784 x N. N is the number of images. 
%         parameters: a struct containing the weights and biases (W1, b1,
%         W2, b2, etc.)
% Output: 
%         Y_pred: a 10 x N array containing the predicted labels of each input image.
%
% (Hint: The predicted class is the class which has the highest probability.  )

    forward_pass = forward_propagation(X, parameters);%Start prediction by running a forward pass
    Y_pred = forward_pass{end} == max(forward_pass{end});%Make prediction by finding highest probability
end