%% Main File
%Name: Logan Hall
%UID: 206295698
%File Name: project_206295698.m
%File Description:
%The main function for this problem. Loads data, trains neural network,
%tests neural network and plots results for visualization of training
%progress
%Run this file to execute the homework 3 problem





%Reset workspace
clear all; close all; clc;

%Define ranges of epochs, learning rate, and number of layers
vary_epoch = [50 150 300];%Epoch can be 50, 150, or 300
vary_lr = [0.1 0.01 0.001];%lr can be 0.1, 0.01, or 0.001
vary_numLayer = [2 3 5];%numLayer can be 2, 3, or 5

%% Load Training and Testing Data
[X_train, Y_train, X_test, Y_test] = load_train_and_test_data();

%% Define network architecture and hyperparameters
input_size = size(X_train, 1); % input size of the FNN
output_size = size(Y_train, 1);% output size (number of classes) of the FNN
neurons = 64;  % neurons each layer

numLayer = 2; %default number of hidden layers. Will be overridden if vry_numLayer is implemented
lr = 0.01; % learning rate.  Will be overridden if vry_lr is implemented
epochs = 150; % epochs.  Will be overridden if vry_epochs is implemented



%for ii = 1:3 %For loop to vary number of epochs, learning rate, or number of layers

tic % start timer

%epochs = vary_epoch(ii);
%lr = vary_lr(ii);
%numLayer = vary_numLayer(ii)
 

layer_dims = zeros(1, numLayer + 2);
%define the dimesnion of the first layer
layer_dims(1) = input_size;
%define the dimesnion of the last layer
layer_dims(end) = output_size;
%define the dimesnion of the hidden layers
for i = 1:numLayer
    layer_dims(i+1) = neurons;
end


%% Train the model
%initialize the parameters
parameters = initialize_parameters(layer_dims);

% Train the model using mini-batch gradient descent
m = size(X_train, 2);
%define the batch size
batch_size = 64;
%Calculate the number of batches
num_batches = floor(m / batch_size);
%initialize trainLoss and testAccuracy
trainLoss = zeros(epochs, 1);
testAccuracy = zeros(epochs, 1);
for i = 1:epochs
    % Shuffle the training data
    indices = randperm(m);
    X_train = X_train(:, indices);
    Y_train = Y_train(:, indices);
    
    % Initialize cost matrix
    cost = zeros(num_batches, batch_size);
    
    % Train on mini-batches
    for j = 1:num_batches
        X_batch = X_train(:, (j-1)*batch_size+1:j*batch_size);
        Y_batch = Y_train(:, (j-1)*batch_size+1:j*batch_size);
        %Do a forward pass
        forward_pass = forward_propagation(X_batch, parameters);
        %Calculate the cost
        cost(j,:) = compute_cost(forward_pass{end}, Y_batch);
        %Do a backwards pass
        gradients = backward_propagation(X_batch, Y_batch, parameters, forward_pass);
        %Update the parameters
        parameters = update_parameters(parameters, gradients, lr);
    end

    %Make predictions
    Y_pred = predict(X_test, parameters);
    %Check the accuracy of the predictions
    acc = accuracy(Y_pred, Y_test);
    % Print the cost each epoch
    fprintf('Loss after epoch %d: Training: %f\n', i, norm(cost));
    trainLoss(i) = norm(cost);
    testAccuracy(i) = acc;
end
    

%% Evaluate the model on the test set
fprintf('Test accuracy: %f\n', testAccuracy(end));

%% Visualize the training progress
%Plot the testaccuracy and trainless with respect to epochs
visualizeHistory(epochs, trainLoss, testAccuracy, lr, numLayer);
toc %end timer


%end %end of for loop if varying hyperparameters